package com.sunbeam;

public class Member {
	int memberId;
	String memberName;
	String memberEmail;
	long memberMobNo;
	
	public Member(int memberId, String memberName, String memberEmail, long memberMobNo2) {
		this.memberId = memberId;
		this.memberName = memberName;
		this.memberEmail = memberEmail;
		this.memberMobNo = memberMobNo2;
	}
	
	public int getMemberId() {
		return memberId;
	}
	public void setMemberId(int memberId) {
		this.memberId = memberId;
	}
	public String getMemberName() {
		return memberName;
	}
	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}
	public String getMemberEmail() {
		return memberEmail;
	}
	public void setMemberEmail(String memberEmail) {
		this.memberEmail = memberEmail;
	}
	public long getMemberMobNo() {
		return memberMobNo;
	}
	public void setMemberMobileNo(long memberMobNo) {
		this.memberMobNo = memberMobNo;
	}

	@Override
	public String toString() {
		return "Member [memberId=" + memberId + ", memberName=" + memberName + ", memberEmail=" + memberEmail
				+ ", memberMobNo=" + memberMobNo + "]";
	}
	
	
}
