package com.sunbeam;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class MemberService {
	List<Member> memberList = new ArrayList<>();
	
	public void addMember(Scanner sc) throws MemberAlreadyExistsException{
		System.out.println("Enter the Member Id you want to Enter: ");
		int memberId = sc.nextInt();
		sc.nextLine();
		
		for(Member member : memberList) {
			if(member.getMemberId() == memberId) {
				throw new MemberAlreadyExistsException("Member with Id "+ memberId + " already Exists!");
			}
		}
		
		System.out.println("Enter the Member Name you want to Enter: ");
		String memberName = sc.nextLine();
		
		System.out.println("Enter the Member's Email : ");
		String memberEmail = sc.nextLine();
		
		System.out.println("Enter the mobile number of the Member you want to enter : ");
		long memberMobNo = sc.nextLong();
		sc.nextLine();
		
		Member newMember = new Member(memberId, memberName, memberEmail, memberMobNo);
		memberList.add(newMember);
		System.out.println("Member Entered Successfully!");
	}

	public void viewAllMembers(Scanner sc) {
		System.out.println("List Of All Members : ");
		if(memberList.isEmpty()) {
			System.out.println("No member to view!");
		} else {
		for(Member member : memberList) {
			System.out.println(member);
		}
		}
	}
	
	public void viewMemberById(Scanner sc) throws MemberNotFoundException {
		System.out.println("Enter the id of member You want to view : ");
		int memberId = sc.nextInt();
		boolean found = false;
		
		for(Member member : memberList) {
			if(member.getMemberId() == memberId) {
				found = true;
				System.out.println("Member Found! CurrentDetails");
				System.out.println("Id : "+member.getMemberId());
				System.out.println("Name : "+member.getMemberName());
				System.out.println("Email : "+member.getMemberEmail());
				System.out.println("Mobile No : "+member.getMemberMobNo());
				break;
			} 		
	}
		if(!found) {
			throw new MemberNotFoundException("Member with Id " + memberId + " not found!");
		}
}
	public void updateMemberById(Scanner sc) throws MemberNotFoundException{
		System.out.println("Enter the id of member you want to update : ");
		int memberId = sc.nextInt();
		sc.nextLine();
		boolean found = false;
		
		for(Member member : memberList) {
			if(member.getMemberId() == memberId) {
				found = true;
				System.out.println("Current Details");
				System.out.println(member);
				
				System.out.println("Enter the updated name of the member(or press enter to skip) : ");
				String memberName = sc.nextLine();
				if(!memberName.trim().isEmpty()) {
					member.setMemberName(memberName);
				}
				
				System.out.println("Enter the updated email of the member(or press enter to skip) : ");
				String memberEmail = sc.nextLine();
				if(!memberEmail.trim().isEmpty()) {
					member.setMemberEmail(memberEmail);
				}
				
				System.out.println("Enter the updated mobile number of the member(or press enter to skip) : ");
				long memberMobNo = sc.nextLong();
				if(String.valueOf(memberMobNo).length() == 10) {
					member.setMemberMobileNo(memberMobNo);
					System.out.println("Mobile number updated successfully!");
				} else {
					System.out.println("Invalid Mobile number!");
				}
				break;
			}
			
		}
		if(!found) {
		throw new MemberNotFoundException("Member with provided Id " + memberId + " not found!");
		}
	}
	
	public void deleteMember(Scanner sc) throws MemberNotFoundException {
		System.out.println("Enter the id of member you want to delete : ");
		int memberId = sc.nextInt();
		boolean found = false;
		
		for(int i = 0; i < memberList.size(); i++) {
			if(memberList.get(i).getMemberId() == memberId) {
				memberList.remove(i);
				found = true;
				System.out.println("member with given id found and deleted successfully!");
				break;
			}
		} if(!found) {
			throw new MemberNotFoundException("Member with Given id " + memberId + " not found!");
		}
	}
	
}
