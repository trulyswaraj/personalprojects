package com.sunbeam;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		MemberService service = new MemberService();
		
		int choice = 0;
		
		while(true) {
		System.out.println("--------Library MemberShip Management System--------");
		System.out.println();
		System.out.println("1. Add Member");
		System.out.println("2. View All Members");
		System.out.println("3. View Member by Id");
		System.out.println("4. Update Member Information");
		System.out.println("5. Delete Member Record");
		System.out.println("6. Exit");
		System.out.println();
		System.out.println("-------Choose Any ONE Option from above-------");
	
		choice = sc.nextInt();
		
		switch(choice) {
		case 1 :
			try {
				service.addMember(sc);
			} catch (MemberAlreadyExistsException e) {
				System.out.println("Member Already Exists!");
				e.printStackTrace();
			}
			break;
		case 2 :
			service.viewAllMembers(sc);
			break;
		case 3 :
			try {
				service.viewMemberById(sc);
			} catch (MemberNotFoundException e) {
				System.out.println("Member with provided id Not found!");
				e.printStackTrace();
			}
			break;
		case 4 :
			try {
				service.updateMemberById(sc);
			} catch (MemberNotFoundException e) {
				System.out.println("Member with provided id not found!");
				e.printStackTrace();
			}
			break;
		case 5 :
			try {
				service.deleteMember(sc);
			} catch(MemberNotFoundException e) {
				System.out.println("Member with provided id not found!");
				e.printStackTrace();
			}
			break;
		case 6 :
			System.out.println("The System Exiting....! Goooooood Byeeeee");
			System.exit(0);
		}
		}
	}
}
