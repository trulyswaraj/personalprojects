package com.sunbeam;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		BookService service = new BookService();
		int choice = 0;
		
		while(true) {
			System.out.println("----------Book Rental System----------");
			System.out.println();
			System.out.println("1. Add New Book");
			System.out.println("2. View All Books");
			System.out.println("3. View Book By Id");
			System.out.println("4. Update a Book");
			System.out.println("5. Delete a Book");
			System.out.println("6. Exit");
			System.out.println();
			System.out.println("----------Choose Any One Option From Above----------");
			
			choice = sc.nextInt();
			
			switch(choice) {
			case 1: 
				service.addBook(sc);
				break;
			case 2:
				service.viewAllBooks(sc);
				break;
			case 3:
				service.viewBookById(sc);
				break;
			case 4:
				service.updateBook(sc);
				break;
			case 5: 
				service.deleteBook(sc);
				break;
			case 6: 
				System.out.println("System exiting! Goooooooood Byeeeeeeeee");
				System.exit(0);
				break;
			}
		}
	}
}