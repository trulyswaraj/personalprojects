package com.sunbeam;

public class Book {
	int bookId;
	String bookName;
	String authorName;
	boolean isAvailable;
	
	public Book(int bookId, String bookName, String authorName, boolean isAvailable) {
		this.bookId = bookId;
		this.bookName = bookName;
		this.authorName = authorName;
		this.isAvailable = isAvailable;
	}
	
	public int getBookId() {
		return bookId;
	}
	
	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public String getAuthorName() {
		return authorName;
	}

	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}

	public boolean isAvailable() {
		return isAvailable;
	}

	public void setAvailable(boolean isAvailable) {
		this.isAvailable = isAvailable;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	@Override
	public String toString() {
		return "Book [bookId=" + bookId + ", bookName=" + bookName + ", authorName=" + authorName + ", isAvailable="
				+ isAvailable + "]";
	}
	
}

	