package com.sunbeam;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class BookService {
	List<Book> bookList = new ArrayList<>();
	
	public void addBook(Scanner sc) {
		System.out.println("Enter the book id you want to enter: ");
		int bookId = sc.nextInt();
		sc.nextLine();
		
		System.out.println("Enter Name of book you want to enter: ");
		String bookName = sc.nextLine();
//		sc.nextLine();
		
		System.out.println("Enter name of Author you want to enter: ");
		String authorName = sc.nextLine();
//		sc.nextLine();
		
		System.out.println("Enter the status of book available/not available : ");
		boolean isAvailable = sc.nextBoolean();
//		sc.nextLine();
		
		Book newBook = new Book(bookId, bookName, authorName, isAvailable);
		bookList.add(newBook);
		System.out.println("New Book Added Successfully!");
	}
	
	public void viewAllBooks(Scanner sc) {
		if(bookList.isEmpty()) {
			System.out.println("The BookList is Empty!");
		} else {
			for(Book bk : bookList) {
				System.out.println(bk);
			}
		}
	}
	
	public void viewBookById(Scanner sc) {
		System.out.println("Enter the book id you want to search : ");
		int bookId = sc.nextInt();
		boolean found = false;
		for(Book bk : bookList) {
		if(bk.getBookId() == bookId) {
			found = true;
			System.out.println("Book Found!");
			System.out.println("Id : " + bk.getBookId());
			System.out.println("BookName: " + bk.getBookName());
			System.out.println("Author Name: " + bk.getAuthorName());
			System.out.println("Availablity: " + bk.isAvailable());
			break;
		}
	}
		if(!found) {
			System.out.println("Book with Id " + bookId + " not Found!");
		}
	}
	
	public void updateBook(Scanner sc) {
		System.out.println("Enter the book id you want to update : ");
		int bookIdToUpdate = sc.nextInt();
		sc.nextLine();
		boolean found = false;
		
		for(Book bk : bookList) {
			if(bk.bookId == bookIdToUpdate) {
				found = true;
				System.out.println("Book found current details!");
				System.out.println(bk);
				
				System.out.println("Enter the new book name(or press enter to skip!)");
				String bookName = sc.nextLine();
				if(!bookName.trim().isEmpty()) {
					bk.setBookName(bookName);
				}
				
				System.out.println("Enter the new Author's name(or press enter to skip!)");
				String authorName = sc.nextLine();
				if(!authorName.trim().isEmpty()) {
					bk.setAuthorName(authorName);
				}
				
				System.out.println("Enter the new Availabitly(yes/no) of book(or press enter to skip!)");
				String isBookAvailable = sc.nextLine();
				if(isBookAvailable.equalsIgnoreCase("yes")) {
					bk.setAvailable(true);
				} else if(isBookAvailable.equalsIgnoreCase("no")) {
					bk.setAvailable(false);
				}
				
				System.out.println("Book updated Successfully!");
				break;
			}
		}
		if(!found) {
			System.out.println("Book with id " + bookIdToUpdate + " Not Found!");
		}
	}
	
	public void deleteBook(Scanner sc) {
		System.out.println("Enter the bookId you want to delete: ");
		int bookId = sc.nextInt();
		boolean found = false;
		
		for(int i = 0; i < bookList.size(); i++) {
			if(bookList.get(i).getBookId() == bookId) {
				bookList.remove(i);
				found = true;
				System.out.println("Book found and Deleted Succesfully!");
				break;
			}
		}
		if(!found) {
			System.out.println("Book Not Found!");
		}
	}
	
}
