const express = require('express');
const router = express.Router();
const Blog = require('../models/Blog');
const {protect} = require('../middleware/authMiddleware');

//get-all-blogs
router.get('/get-all-blogs', async (req, res)=>{
    try{
        const blogs = await Blog.find();
        res.json(blogs);
    } catch(err){
        res.status(500).json({message:err.message});
    }
});

//get-blog-by-id
router.get('/get-blog-by-id/:id', async(req, res)=>{
    try{
        const blog = await Blog.findById(req.params.id);
        if(!blog) 
            return res.status(404).json({message:'Blog Not Found!'});
        res.json(blog);
    } catch(err){
        res.status(500).json({message:err.message});
    }
});

//post-new-blog
router.post('/post-new-blog',protect ,async(req, res)=>{
    const {title, content} = req.body;
    const newBlog = new Blog({title, content, author: req.user._id});
    try{
        const savedBlog = await newBlog.save();
        res.status(201).json(savedBlog);
    } catch(err){
        res.status(400).json({message:err.message});
    }
});

// //update-blog-using-id
// router.put('/update-blog-using-id/:id', async(req, res)=>{
//     const {title, content} = req.body;
//     try{
//         const updatedBlog = await Blog.findByIdAndUpdate(req.params.id,{title, content}, {new: true});
//         res.json(updatedBlog);
//     } catch(err){
//         res.status(400).json({message:err.message});
//     }
// });
router.put('/update-blog-using-id/:id', async (req, res) => {
    const { title, content } = req.body;
    try {
        const updatedBlog = await Blog.findByIdAndUpdate(
            req.params.id,
            { title, content },
            { new: true, runValidators: true }
        );

        if (!updatedBlog) {
            return res.status(404).json({ message: 'Blog not found!' });
        }

        res.json(updatedBlog);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});


// delete-blog-using-id
router.delete('/delete-blog-by-id/:id', async (req, res) => {
    try {
        const deletedBlog = await Blog.findByIdAndDelete(req.params.id);
        if (!deletedBlog) {
            return res.status(404).json({ message: 'Blog not found!' });
        }
        res.json({ message: 'Blog deleted Successfully!' });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});


module.exports = router;