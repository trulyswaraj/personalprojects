const Blog = require('../models/Blog');

exports.createBlog = async(req, res) => {
    const{title, content} = req.body;
    try{
        const blog = new Blog({
            title,
            content,
            author: req.user._id,
        });
    const createdBlog = await blog.save();
    res.status(201).json(createdBlog);
    } catch(err){
        res.status(500).json({message: "Failed to create a blog!"});
    }
};

exports.getAllBlogs = async(req, res) => {
    try{
        const blogs = await Blog.find().populate('author', 'name email');
        json.res(blogs);
    } catch(err){
        res.status(500).json({message: "Failed to fetch Blogs!"});
    }
};

exports.getBlogById = async(req, res) =>{
    try{
        const blog = await Blog.findById(req.params._id).populate('author', 'name');
        if(!blog)
            return res.status(404).json({message:"Blog Not Found!"});
        res.json(Blog);
    } catch(err){
        res.status(500).json({message: "Failed to fetch Blog!"});
    }
};

exports.updateBlog = async(req, res) => {
    const{title,content} = req.body;
    try{
        const blog = await Blog.findById(req.params._id);
        if(!blog) 
            return res.status(404).json({message:"Blog not Found!"});
        blog.title = title || blog.title;
        blog.content = content || blog.content;

        const updateBlog = await blog.save();
        res.json(updateBlog);
    } catch(err){
        res.status(500).json({message:"Failed to Update Blog!"});
    }
};

exports.deleteBlog = async(req, res) =>{
    try{
        const blog = await Blog.findById(req.params.id);
        if(!blog) return res.status(404).json({message: "Blog Not Found!"});

        if(blog.author.toString() !== req.user._id.toString()){
            return res.status(401).json({message:"Not Authorized!"});
        }
        await blog.remove();
        res.json({message:"Blog Deleted Successfully!"});
    } catch(err){
        res.status(500).json({message:"Failed to delete Blog!"});
    }
};