const User = require('../models/User');
const bcrypt = require('bcrypt');
const generateToken = require('../utils/generateToken');

exports.registerUser = async(req, res)=> {
    const{name, email, password} = req.body;
    try{
        const userExists = await User.findOne({email});
        if(userExists) 
            return res.status(400).json({message:"User Already Exists!"});
        
        const hashedPassword = await bcrypt.hash(password, 10);
        const user = await User.create({name, email, password: hashedPassword});

        res.status(201).json({
            _id: user._id,
            name: user.name,
            email: user.email,
            token : generateToken(user._id)
        });
    } catch(err){
        res.status(500).json({message: "Server Error!"});
    }
};

exports.loginUser = async(req, res)=>{
    const{email, password} = req.body;
    try{
        const existingUser = await User.findOne({email});
        if(!existingUser){
            return res.status(401).json({message:'Invalid email or password'});
        }
        const isMatch = await bcrypt.compare(password, User.password);
        if(!isMatch){
            return res.status(401).json({message: 'Password Didnt Matched! Invalid User!'});
        }
        res.status(200).json({
            _id: user._id,
            name: user.name,
            email: user.email,
            token: generateToken(user._id),
        });
    } catch(err){
        console.log(err);
        res.status(500).json({message:'Server Error!'});
    }
};


exports.getUserProfile = async(req, res)=>{
    try{
        const user = await User.findById(req.user._id).select('-password');
        if(!user){
            return res.status(404).json({message:'User not found!'});
        }
        res.status(200).json(user);
    } catch(err){
        res.status(500).json({message: 'Server Error!'});
    }
};

exports.updateUserProfile = async(req, res)=>{
    try{
        const user = await User.findById(req.user._id);
        if(!user){
            return res.status(404).json({message:'User Not Found!'});
        }
        user.name = req.body.name || user.name;
        user.email = req.body.email || user.email;

        if(req.body.password){
            user.password = await bcrypt.hash(req.body.password, 10);
        }
        const updatedProfile = await User.save();
        res.json({
            _id: updatedUser._id,
            name: updateUser.name,
            email: updatedUser.email,
            token:generateToken(updatedUser._id),
        });
    } catch(err){
        res.status(500).json({message: 'Server Error!'});
    }
};

exports.deleteOwnProfile = async(req, res) => {
    try{
        const user = await User.findById(req.user._id);
        if(!user)
            return res.status(400).json({message:"User Not Found!"});
        await user.remove();
        res.json({message: "Your Account Has been Deleted!"});
    } 
    catch(err){
        res.status(500).json({message: "Server Error!"});
    }
};

exports.deleteUserById = async(req, res) => {
    try{
        const user = await User.findById(req.params._id);
        if(!user) 
            return res.status(404).json({message: "User Not Found!"});
        await user.remove();
        res.json({message: `User ${user.name} deleted Successfully!`});
    }
    catch(err){
        res.status(500).json({message:"Server Error!"});
    }
};