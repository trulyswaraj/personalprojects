package com.sunbeam;

public class ProductClass {
	int productId;
	String productName;
	double price;
	int stockQuantity;
	
	public ProductClass( int productId, String productName, double price, int stockQuantity) {
		this.productId = productId;
		this.productName = productName;
		this.price = price;
		this.stockQuantity = stockQuantity;
	}
	
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getStockQuantity() {
		return stockQuantity;
	}
	public void setStockQuantity(int stockQuantity) {
		this.stockQuantity = stockQuantity;
	}
	@Override
	public String toString() {
		return "ProductClass [productId=" + productId + ", productName=" + productName + ", price=" + price
				+ ", stockQuantity=" + stockQuantity + "]";
	}
	
	public void reduceStock(int purchasedQuantity) throws  InsufficientStockException{
		if(this.stockQuantity >= purchasedQuantity) {
			this.stockQuantity -= purchasedQuantity;
		} else {
			throw new InsufficientStockException("Not Enough stock available!" + productName);
		}
	}
	
}
