package com.sunbeam;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ShoppingCartService {
	List<ProductClass> productList = new ArrayList<>();
	List<CartItem> userCart = new ArrayList<>();
	
	public void addToCart(Scanner sc) throws NoSuchProductException, InsufficientStockException{
		if(productList.isEmpty()) {
			System.out.println("No Products Available to add to cart!");
			return;
		}
		
		System.out.println("Available Products : ");
		for(ProductClass p : productList) {
			System.out.println(p.getProductId() + " - " + p.getProductName() + " - Rs.  " + p.getPrice() + " - Stock: " + p.getStockQuantity());
		}
		System.out.println("Enter the product id to add it to the cart  : ");
		int productId = sc.nextInt();
		
		ProductClass selectedProduct = null;
		for(ProductClass p : productList) {
			if(p.getProductId() == productId) {
				selectedProduct = p;
				break;
			}
		}
		
		if(selectedProduct == null) {
			throw new NoSuchProductException("No Product Exists with Id : " + productId);
		}
		
		System.out.println("Enter the quantity to add to cart :");
		int quantity = sc.nextInt();
		
		if(quantity <= 0) {
			System.out.println("Invalid Quantity! Must be greater than zero!");
			return;
		}
		
		if(selectedProduct.getStockQuantity() < quantity) {
			throw new InsufficientStockException("Not enough stock for product : " + selectedProduct.getProductName());
		}
		
		selectedProduct.setStockQuantity(selectedProduct.getStockQuantity() - quantity);
		
		CartItem item = new CartItem(selectedProduct, quantity);
		userCart.add(item);
		
		System.out.println(quantity + " units of " + selectedProduct.getProductName());
	}
	
	public void addProduct(Scanner sc) throws ProductAlreadyExistsException {
		System.out.println("Enter the Product Id you want to add : ");
		int productId = sc.nextInt();
		sc.nextLine();
		
		System.out.println("Enter the Product Name you want to add : ");
		String productName = sc.nextLine();
		
		System.out.println("Enter the Price of product you want to add : ");
		double price = sc.nextDouble();
		
		System.out.println("Enter the Stick Quantity of the product you want to add : ");
		int stockQuantity = sc.nextInt();
		
		ProductClass newProduct = new ProductClass(productId , productName, price, stockQuantity);
		productList.add(newProduct);
		System.out.println("New Product Added Successfully!");
	}
	
	public void removeProduct(Scanner sc) throws NoSuchProductException{
		if(productList.isEmpty()) {
			System.out.println("The list is empty!");
			return;
		}
		
		System.out.println("Current Products: ");
		for(ProductClass p : productList) {
		    System.out.println(p.getProductId() + " - " + p.getProductName());
		}
		
		System.out.println("Enter the id of product you want to remove: ");
		int productId = sc.nextInt();
		boolean found = false;
		
		for(int i = 0; i < productList.size(); i++) {
			if(productList.get(i).getProductId() == productId) {
				productList.remove(i);
				found = true;
				System.out.println("Product Removed Successfully!");
				break;
			}
		}
		if(!found) {
			throw new NoSuchProductException("No Product Exits with Id " + productId);
		}
	}
	
	public void updateProduct(Scanner sc) throws NoSuchProductException {
		if(productList.isEmpty()) {
			System.out.println("The list is Empty! hence cannot update!");
		}
		
		System.out.println("Enter the id you want to update!");
		int productId = sc.nextInt();
		sc.nextLine();
		boolean found = false;
		
		for(ProductClass product : productList) {
			if(product.getProductId() == productId) {
				found = true;
				System.out.println("Enter the updated product name : ");
				String productName = sc.nextLine();
				product.setProductName(productName);
				System.out.println("Product Name Updated ");
				
				System.out.println("Enter the updated Product Price : ");
				double productPrice = sc.nextDouble();
				product.setPrice(productPrice);
				System.out.println("Product price updated successfully!");

				System.out.println("Enter the updated Stock Quantity : ");
				int stockQuantity = sc.nextInt();
				product.setStockQuantity(stockQuantity);
				System.out.println("Product Stock Quantity Updated Successfully!");
			}
		}
		if(!found) {
			throw new NoSuchProductException("No element with the provided element Found!");
		}
	}
	
	public void calTotal(Scanner sc) {
		if(userCart.isEmpty()) {
			System.out.println("Your cart is empty! Total = Rs. 00.00");
			return;
		}
		double total = 0.0;
		System.out.println("Cart Summary : ");
		for(CartItem item : userCart) {
			ProductClass product = item.getProduct();
			double subtotal = product.getPrice() * item.getQuantity();
			total += subtotal;
			System.out.println(product.getProductName() + " x " + item.getQuantity() + " = Rs " + subtotal);
		}
		System.out.println("Total Amount : Rs " + total);
	}
	
	public void displayCart(Scanner sc) {
		if(userCart.isEmpty()) {
			System.out.println("Your cart is Empty!");
			return;
		}
		System.out.println("Items in your cart : ");
		for(CartItem item : userCart) {
			ProductClass product = item.getProduct();
			System.out.println("Product : " + product.getProductName() 
													+ " | Quantity : " + item.getQuantity()
													+ "| Price per unit : Rs " + product.getPrice() 
													+ "| Subtotal : Rs " + (product.getPrice() * item.getQuantity()));
		}
	}
	
}
