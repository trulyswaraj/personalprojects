package com.sunbeam;

public class CartItem {
	private ProductClass product;
	private int quantity;

	public CartItem(ProductClass product, int quantity) {
		this.product = product;
		this.quantity = quantity;
	}


	
	public ProductClass getProduct() {
		return product;
	}

	public void setProduct(ProductClass product) {
		this.product = product;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
}
