package com.sunbeam;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		ShoppingCartService service = new ShoppingCartService();
		int choice  = 0;
		
		while(true) {
			System.out.println("--------------Online Shopping Cart Management System--------------");
			System.out.println();
			System.out.println("1. Add Product");
			System.out.println("2. Remove Product");
			System.out.println("3. Update Product");
			System.out.println("4. Add To Cart");
			System.out.println("5. Calculate Total");
			System.out.println("6. Display Cart");
			System.out.println("7. Exit");
			System.out.println();
			System.out.println("--------------Choose Any One From Above Options--------------");
		
			choice = sc.nextInt();
			
			switch(choice) {
			case 1 :
				try{ 
					service.addProduct(sc);
				} catch (ProductAlreadyExistsException e){
					System.out.println("Product Already Exists!");
					e.printStackTrace();
				}
				break;
			case 2 :
				try {
					service.removeProduct(sc);
				} catch(NoSuchProductException e) {
					System.out.println("Product Doesnt Exists!");
					e.printStackTrace();
				}
				break;
			case 3 :
				try {
					service.updateProduct(sc);
				} catch(NoSuchProductException e) {
					System.out.println("Product Doesnt Exsits!");
					e.printStackTrace();
				}
				break;
			case 4 :
				try {
					service.addToCart(sc);
				} catch (NoSuchProductException | InsufficientStockException e) {
					System.out.println(e.getMessage());
				}
				break;
			case 5 :
				service.calTotal(sc);
				break;
			case 6 :
				service.displayCart(sc);
				break;
			case 7 :
				System.out.println("System Exiting...Goooood Byeeee!");
				System.exit(0);
			}
		
		}
		
	}
}
